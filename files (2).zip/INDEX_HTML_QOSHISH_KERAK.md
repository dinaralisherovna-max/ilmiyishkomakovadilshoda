# index.html ga QO'SHISH KERAK BO'LGAN KODLAR

## 1-qadam: <head> ichiga qo'shing (manifest uchun)

```html
<!-- PWA Manifest -->
<link rel="manifest" href="manifest.json">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="O'zbek tili">
<meta name="theme-color" content="#2DB87A">
```

## 2-qadam: </body> tugashidan OLDIN qo'shing (Service Worker uchun)

```html
<script>
  // Service Worker ro'yxatdan o'tkazish
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js')
        .then((reg) => {
          console.log('✅ Offlain rejim yoqildi!', reg.scope);
        })
        .catch((err) => {
          console.log('❌ Service Worker xatosi:', err);
        });
    });
  }
</script>
```

---

## MUHIM: sw.js dagi FILES_TO_CACHE ni to'ldiring

Agar sizda alohida CSS, JS, rasm fayllari bo'lsa, sw.js ichidagi
ro'yxatga qo'shing:

```javascript
const FILES_TO_CACHE = [
  './',
  './index.html',
  './style.css',      // ← CSS faylingiz bo'lsa
  './app.js',         // ← JS faylingiz bo'lsa
  './icon-192.png',   // ← rasmlar bo'lsa
];
```

---

## GitHub Pages ga yuklash tartibi:

1. `sw.js` faylini repo ildiziga yuklang (index.html bilan bir joyda)
2. `manifest.json` faylini repo ildiziga yuklang
3. `index.html` ga yuqoridagi 2 kod parchani qo'shing
4. Commit & Push qiling
5. Tayyor! Bir marta internet bilan kirsin, keyin offlain ishlaydi.

---

## Telefonga o'rnatish (ixtiyoriy):

- Android Chrome: "Bosh ekranga qo'shish" tugmasi avtomatik chiqadi
- iOS Safari: "Share → Add to Home Screen" tugmasini bosing
