// =============================================
// SERVICE WORKER — O'zbek tili platformasi
// Barcha fayllarni keshlab offline ishlaydi
// =============================================

const CACHE_NAME = 'uzbektili-v1';

// Keshlanadigan fayllar ro'yxati
const FILES_TO_CACHE = [
  './',
  './index.html',
  // Agar sizda qo'shimcha fayllar bo'lsa, shu yerga qo'shing:
  // './style.css',
  // './app.js',
  // './icon-192.png',
  // './icon-512.png',
];

// ---- O'rnatish: barcha fayllarni keshga olish ----
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Fayllar keshga olinmoqda...');
      return cache.addAll(FILES_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// ---- Faollashuv: eski keshlarni o'chirish ----
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keyList) =>
      Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[SW] Eski kesh o\'chirildi:', key);
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

// ---- So'rovlarni ushlash: avval keshdan, keyin internetdan ----
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse; // Keshdan qaytarish
      }
      // Internetdan olib, keshga saqlash
      return fetch(event.request).then((networkResponse) => {
        if (
          networkResponse &&
          networkResponse.status === 200 &&
          networkResponse.type === 'basic'
        ) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return networkResponse;
      }).catch(() => {
        // Internet yo'q va keshda ham yo'q — asosiy sahifani qaytarish
        return caches.match('./index.html');
      });
    })
  );
});
